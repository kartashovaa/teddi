package com.example.feature

import org.junit.Assert.assertTrue
import org.junit.Test

class FeatureViewModelTest {

    private val viewModel = FeatureViewModel()

    @Test
    fun successTest() {
        viewModel.doSomething()

        assertTrue(true)
    }
}