package com.example.feature

class FeatureViewModel {

    fun doSomething() {
        // change to trigger tests
    }
}