package com.example.app

class MainViewModel {

    fun doSomething() {
        // change to trigger tests
    }
}