package com.example.app

import org.junit.Assert.assertTrue
import org.junit.Test

class MainViewModelTest {

    @Test
    fun successTest() {
        assertTrue(true)
    }
}