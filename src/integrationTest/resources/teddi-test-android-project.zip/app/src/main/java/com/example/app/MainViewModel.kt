package com.example.app

class MainViewModel {

    fun doStuff() {
        TODO()
    }
}