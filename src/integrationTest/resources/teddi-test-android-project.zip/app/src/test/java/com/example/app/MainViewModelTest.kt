package com.example.app

import org.junit.Assert.assertEquals
import org.junit.Test


internal class MainViewModelTest {

    @Test
    fun test() {
        assertEquals(4, 2 + 2)
    }

}