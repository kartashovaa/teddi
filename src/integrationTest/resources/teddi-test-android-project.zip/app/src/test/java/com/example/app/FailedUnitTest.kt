package com.example.app

import org.junit.Test

import org.junit.Assert.*

class FailedUnitTest {

    @Test
    fun failed() {
        error("Failed successfully")
    }
}