package com.example.testcase

import org.junit.Test

class UnitTests {

    @Test
    fun failed(): Unit = error("Must not be called")
}
