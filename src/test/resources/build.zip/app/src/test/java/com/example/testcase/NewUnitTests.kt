package com.example.testcase

import org.junit.Test

class NewUnitTests {

    @Test
    fun passed() {
        // does nothing on purpose
    }
}
