package androidAppModule0packageJava0;

import org.junit.Test;

public class Foo0Test {
  @Test
  public void testFoo0() {
    new Foo0().foo0();
  }

  @Test
  public void testFoo1() {
    new Foo0().foo1();
  }

  @Test
  public void testFoo2() {
    new Foo0().foo2();
  }

  @Test
  public void testFoo3() {
    new Foo0().foo3();
  }

  @Test
  public void testFoo4() {
    new Foo0().foo4();
  }
}
