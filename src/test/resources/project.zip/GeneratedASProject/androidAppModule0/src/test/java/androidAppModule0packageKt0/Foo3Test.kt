package androidAppModule0packageKt0;

annotation class Foo3TestFancy
@Foo3TestFancy
class Foo3Test {

  @org.junit.Test
  fun testFoo0(){
    Foo3().foo0()
  }

  @org.junit.Test
  fun testFoo1(){
    Foo3().foo1()
  }

  @org.junit.Test
  fun testFoo2(){
    Foo3().foo2()
  }

  @org.junit.Test
  fun testFoo3(){
    Foo3().foo3()
  }

  @org.junit.Test
  fun testFoo4(){
    Foo3().foo4()
  }
}