package androidAppModule0packageJava0;

public class Foo0 {
  public void foo0() {
    new androidAppModule1packageKt0.Foo0().foo4();
    new module0packageKt0.Foo0().foo4();
    new module1packageKt0.Foo0().foo4();
  }

  public void foo1() {
    foo0();
  }

  public void foo2() {
    foo1();
  }

  public void foo3() {
    foo2();
  }

  public void foo4() {
    foo3();
  }
}
