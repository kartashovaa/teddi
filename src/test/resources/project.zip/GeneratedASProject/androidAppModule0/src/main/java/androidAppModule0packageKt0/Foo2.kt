package androidAppModule0packageKt0;

annotation class Foo2Fancy
@Foo2Fancy
class Foo2 {

  fun foo0(){
    androidAppModule0packageKt0.Foo1().foo4()
  }

  fun foo1(){
    foo0()
  }

  fun foo2(){
    foo1()
  }

  fun foo3(){
    foo2()
  }

  fun foo4(){
    foo3()
  }
}