package androidAppModule0packageKt0;

annotation class Foo3Fancy
@Foo3Fancy
class Foo3 {

  fun foo0(){
    androidAppModule0packageKt0.Foo2().foo4()
  }

  fun foo1(){
    foo0()
  }

  fun foo2(){
    foo1()
  }

  fun foo3(){
    foo2()
  }

  fun foo4(){
    foo3()
  }
}