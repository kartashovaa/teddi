package module1packageJava0;

import org.junit.Test;

public class Foo2Test {
  @Test
  public void testFoo0() {
    new Foo2().foo0();
  }

  @Test
  public void testFoo1() {
    new Foo2().foo1();
  }

  @Test
  public void testFoo2() {
    new Foo2().foo2();
  }

  @Test
  public void testFoo3() {
    new Foo2().foo3();
  }

  @Test
  public void testFoo4() {
    new Foo2().foo4();
  }
}
