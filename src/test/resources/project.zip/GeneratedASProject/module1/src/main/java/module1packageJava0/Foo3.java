package module1packageJava0;

public class Foo3 {
  public void foo0() {
    new module1packageJava0.Foo2().foo4();
  }

  public void foo1() {
    foo0();
  }

  public void foo2() {
    foo1();
  }

  public void foo3() {
    foo2();
  }

  public void foo4() {
    foo3();
  }
}
