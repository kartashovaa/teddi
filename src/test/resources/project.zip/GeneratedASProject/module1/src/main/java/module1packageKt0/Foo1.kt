package module1packageKt0;

annotation class Foo1Fancy
@Foo1Fancy
class Foo1 {

  fun foo0(){
    module1packageKt0.Foo0().foo4()
  }

  fun foo1(){
    foo0()
  }

  fun foo2(){
    foo1()
  }

  fun foo3(){
    foo2()
  }

  fun foo4(){
    foo3()
  }
}