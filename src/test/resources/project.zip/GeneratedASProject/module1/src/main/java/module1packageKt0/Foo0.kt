package module1packageKt0;

annotation class Foo0Fancy
@Foo0Fancy
class Foo0 {

  fun foo0(){
    module1packageJava0.Foo0().foo4()
  }

  fun foo1(){
    foo0()
  }

  fun foo2(){
    foo1()
  }

  fun foo3(){
    foo2()
  }

  fun foo4(){
    foo3()
  }
}