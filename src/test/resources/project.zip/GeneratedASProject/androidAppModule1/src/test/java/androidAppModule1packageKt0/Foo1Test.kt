package androidAppModule1packageKt0;

annotation class Foo1TestFancy
@Foo1TestFancy
class Foo1Test {

  @org.junit.Test
  fun testFoo0(){
    Foo1().foo0()
  }

  @org.junit.Test
  fun testFoo1(){
    Foo1().foo1()
  }

  @org.junit.Test
  fun testFoo2(){
    Foo1().foo2()
  }

  @org.junit.Test
  fun testFoo3(){
    Foo1().foo3()
  }

  @org.junit.Test
  fun testFoo4(){
    Foo1().foo4()
  }
}