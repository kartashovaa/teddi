package androidAppModule1packageKt0;

annotation class Foo2TestFancy
@Foo2TestFancy
class Foo2Test {

  @org.junit.Test
  fun testFoo0(){
    Foo2().foo0()
  }

  @org.junit.Test
  fun testFoo1(){
    Foo2().foo1()
  }

  @org.junit.Test
  fun testFoo2(){
    Foo2().foo2()
  }

  @org.junit.Test
  fun testFoo3(){
    Foo2().foo3()
  }

  @org.junit.Test
  fun testFoo4(){
    Foo2().foo4()
  }
}