package com.androidAppModule1;

import android.widget.ImageView;
import java.lang.Override;

public class Activity1 extends android.app.Activity {
  ImageView imageView0;

  ImageView imageView1;

  ImageView imageView2;

  ImageView imageView3;

  ImageView imageView4;

  ImageView imageView5;

  @Override
  public void onCreate(android.os.Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    new androidAppModule1packageJava0.Foo0().foo4();
    setContentView(R.layout.androidappmodule1activity_main1);
  }
}
