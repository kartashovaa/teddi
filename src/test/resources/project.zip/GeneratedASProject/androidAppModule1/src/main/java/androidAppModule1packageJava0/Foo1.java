package androidAppModule1packageJava0;

public class Foo1 {
  public void foo0() {
    new androidAppModule1packageJava0.Foo0().foo4();
  }

  public void foo1() {
    foo0();
  }

  public void foo2() {
    foo1();
  }

  public void foo3() {
    foo2();
  }

  public void foo4() {
    foo3();
  }
}
