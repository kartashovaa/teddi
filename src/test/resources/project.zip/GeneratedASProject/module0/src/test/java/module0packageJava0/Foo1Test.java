package module0packageJava0;

import org.junit.Test;

public class Foo1Test {
  @Test
  public void testFoo0() {
    new Foo1().foo0();
  }

  @Test
  public void testFoo1() {
    new Foo1().foo1();
  }

  @Test
  public void testFoo2() {
    new Foo1().foo2();
  }

  @Test
  public void testFoo3() {
    new Foo1().foo3();
  }

  @Test
  public void testFoo4() {
    new Foo1().foo4();
  }
}
