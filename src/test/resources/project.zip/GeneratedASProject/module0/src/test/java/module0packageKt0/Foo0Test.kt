package module0packageKt0;

annotation class Foo0TestFancy
@Foo0TestFancy
class Foo0Test {

  @org.junit.Test
  fun testFoo0(){
    Foo0().foo0()
  }

  @org.junit.Test
  fun testFoo1(){
    Foo0().foo1()
  }

  @org.junit.Test
  fun testFoo2(){
    Foo0().foo2()
  }

  @org.junit.Test
  fun testFoo3(){
    Foo0().foo3()
  }

  @org.junit.Test
  fun testFoo4(){
    Foo0().foo4()
  }
}